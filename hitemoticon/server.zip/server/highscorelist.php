<?php	
	require_once('JSON.php');

	$Mode = $_POST["SendMode"];
	$playername = $_POST["name"];
	$score = $_POST["score"];
	if ($Mode == null) {
		$Mode = '1';
	}
	
	$dsn = 'mysql:dbname=iwamoto_ranking_database;host=localhost;charset=utf8';
	$user = 'iwamoto';
	$password = 'mbv87827878bbb';

	$json = new Services_JSON();
	
	// �f�[�^�x�[�X�ɐڑ�
	try{
	    $dbh = new PDO(
			$dsn, 
			$user, 
			$password,
			array(
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
				PDO::ATTR_EMULATE_PREPARES => false,
			)
		);
		
	} catch (PDOException $e){
		echo 'comp='.'Error:'.$e->getMessage();
	}
			
	switch($Mode) {
		case 1:
			/* �����L���O�ꗗ�\�� */
			$users = array();
			
			// �~���ɂ��Ă���
			$sql = 'SELECT name,score FROM scoreranking ORDER BY score DESC LIMIT 100;';
			$stmt = $dbh->query($sql);

			while($row = $stmt->fetchObject()) {
				$users[] = $row;
 			}
			echo $json->encode($users);
			break;
			
		case 2:
			/* �����L���O�ɃX�R�A�}�� */
			$today = getdate();
			$todaydate = date("Y-m-d");
			
			$stmt = $dbh->prepare("INSERT INTO scoreranking(id,name,score,insert_time,delete_flag) VALUES(:ID,:NAME,:SCORE,:DATE,:DELETE)");
			echo 'bind complete';

			$stmt->bindValue(':ID', '');
			$stmt->bindValue(':NAME',$playername, PDO::PARAM_STR);
			$stmt->bindValue(':SCORE',$score, PDO::PARAM_INT);
			$stmt->bindValue(':DATE',$todaydate);
			$stmt->bindValue(':DELETE','');
			echo 'bind complete';

			$stmt->execute();
			echo 'complete execute';
			break;
			
		case 3:
			/* �����L���O�̉����X�R�A�擾 */
			echo 'Mode : 3';
			$result = 0;
			
			$sql = $dbh->prepare("SELECT userscore FROM scoreranking ORDER BY score DESC LIMIT 100;");
			$sql->execute();
			$result = $sql->fetchColumn(1);
			if ($result=='') $result = 1;
			
			echo "comp=".$result;
		
		case 4:
			$sql = 'TRUNCATE TABLE scoreranking;';
			$stmt = $dbh->query($sql);
			break;
	}

?>